using System;
using Microsoft.SPOT;
using System.Net;
using System.IO;

namespace IoTKitHoLEmulatorApp
{
    public partial class Program
    {
        static public Guid deviceId = new Guid(/* ������Step1�ڑ� 1.2��Guid���R�s�[���Ă������� */);

        void ProgramStarted()
        {
            TryConnect();

            /*******************************************************************************************
             * 
             * Please write Hands-on code below
             * 
            *******************************************************************************************/
            // ���x�Z���T�[�ϐ�: temperature 
            // var temp = temperature.TakeMeasurements();
            // �����x�Z���T�[�ϐ��F accelerometer
            // var accel = accelerometer.TakeMeasurements();
            // �����[�ϐ�: relay
            // relay.TurnOn(), relay.TurnOff()

            Debug.Print("Program Started");
        }

        public void TryConnect()
        {
            Debug.Print("Please setup Guid for DeviceId - Current:" + deviceId.ToString());
            if (deviceId.ToString() == "00000000-0000-0000-0000-000000000000")
            {
                Debug.Print("Please setup Guid for DeviceId - Current:"+deviceId.ToString());
                throw new ArgumentOutOfRangeException("Please setup Guid for DeviceId");
            }
            var request = HttpWebRequest.Create("http://egiotkitholservice.azurewebsites.net/api/DeviceConnect") as HttpWebRequest;
            request.Headers.Add("device-id", deviceId.ToString());
            request.Headers.Add("device-message", "hello from emulator");
            using (var response = request.GetResponse() as HttpWebResponse)
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var reader = new StreamReader(response.GetResponseStream());
                    string message = reader.ReadToEnd();
                    Debug.Print(message);
                }
            }

        }
    }
}
