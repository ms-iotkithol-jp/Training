EGIoTKit.dll <- EGIoTKit Solution - EGIoTKit Project
EGIoTKitEmulator.Modules <- EGIoTKitEmulator Solution - EGIoTKitEmulator.Modules
