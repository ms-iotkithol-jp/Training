﻿using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace DeviceEmulator
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        DeviceClient deviceClient = null;
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        DispatcherTimer sendTimer;
        long sendIntervalMSec = 10000;
        Random rand;
        FlowDocument statusDoc = new FlowDocument();

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (sendTimer == null)
            {
                sendTimer = new DispatcherTimer();
            }
            sendTimer.Interval = TimeSpan.FromMilliseconds(sendIntervalMSec);
            sendTimer.Tick += SendTimer_Tick;
            rand = new Random(DateTime.Now.Millisecond);
            rtbStatus.Document = statusDoc;
        }

        private async void SendTimer_Tick(object sender, EventArgs e)
        {
            sendTimer.Stop();
            await SendMessageAsync();
            sendTimer.Start();
        }

        private async Task SendMessageAsync()
        {
            double avgWindSpeed = 10; // m/sec
            double currentWindSpeed = avgWindSpeed + rand.NextDouble() * 4 - 2;
            var telemetryDataPoint = new
            {
                deviceId = tbDeviceId.Text,
                windSpeed = currentWindSpeed,
                time = DateTime.Now
            };
            var messageString = JsonConvert.SerializeObject(telemetryDataPoint);
            var message = new Message(Encoding.UTF8.GetBytes(messageString));

            try
            {
                await deviceClient.SendEventAsync(message);
                statusDoc.Blocks.Add(new Paragraph(new Run("Send[" + sendCount++ + "]" + messageString)));
            }
            catch (Exception ex)
            {
                statusDoc.Blocks.Add(new Paragraph(new Run(ex.Message)));
            }
        }

        private int sendCount = 0;
        private void buttonSend_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbIoTHubUri.Text))
            {
                MessageBox.Show("Please input IoT Hub Url.");
                return;
            }
            if (buttonSend.Content.ToString() == "Start")
            {
                if (string.IsNullOrEmpty(tbDeviceId.Text) || string.IsNullOrEmpty(tbDeviceKey.Text))
                {
                    MessageBox.Show("Please input DeviceId and DeviceKey");
                    return;
                }
                try
                {
                    if (deviceClient == null)
                    {
                        deviceClient = DeviceClient.Create(tbIoTHubUri.Text, new DeviceAuthenticationWithRegistrySymmetricKey(tbDeviceId.Text, tbDeviceKey.Text));
                        statusDoc.Blocks.Add(new Paragraph(new Run("Device has been connected to IoT Hub")));
                        ReceiveC2dAsync();
                    }
                    sendTimer.Start();
                    buttonSend.Content = "Stop";
                }
                catch (Exception ex)
                {
                    statusDoc.Blocks.Add(new Paragraph(new Run(ex.Message)));
                }
            }
            else
            {
                sendTimer.Stop();
                buttonSend.Content = "Start";
            }
        }

        private async void ReceiveC2dAsync()
        {
            while (true)
            {
                Message receivedMessage = await deviceClient.ReceiveAsync();
                if (receivedMessage == null) continue;

                statusDoc.Blocks.Add(new Paragraph(new Run(string.Format("Received message: {0}", Encoding.UTF8.GetString(receivedMessage.GetBytes())))));

                await deviceClient.CompleteAsync(receivedMessage);
            }
        }
    }
}
