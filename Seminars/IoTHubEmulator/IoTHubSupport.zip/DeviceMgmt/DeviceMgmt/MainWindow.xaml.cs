﻿using Microsoft.Azure.Devices;
using Microsoft.Azure.Devices.Common.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DeviceMgmt
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        private RegistryManager registyManager;
        public MainWindow()
        {

            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private async void buttonRegist_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbConnectionString.Text))
            {
                MessageBox.Show("Connection Stringを入力してください");
                return;
            }
            if (registyManager == null)
            {
                registyManager = RegistryManager.CreateFromConnectionString(tbConnectionString.Text);
            }
            if (string.IsNullOrEmpty(tbDeviceId.Text))
            {
                MessageBox.Show("DeviceIdを入力してください");
                return;
            }
            Device device = null;
            try
            {
                device = await registyManager.AddDeviceAsync(new Device(tbDeviceId.Text));
                tbStatus.Text = tbDeviceId.Text + " has been registed as New Device.";
            }
            catch (DeviceAlreadyExistsException)
            {
                device = await registyManager.GetDeviceAsync(tbDeviceId.Text);
                tbStatus.Text = tbDeviceId.Text + "has already been registed.";
            }
            if (device != null)
            {
                tbDeviceKey.Text = device.Authentication.SymmetricKey.PrimaryKey;
            }
        }

        private void buttonCopyDKey_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbDeviceKey.Text))
                return;
            Clipboard.SetText(tbDeviceKey.Text);
        }

        private async void buttonRemove_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbDeviceKey.Text))
            {
                return;
            }
            try
            {
                await registyManager.RemoveDeviceAsync(tbDeviceId.Text);
                tbStatus.Text = tbDeviceId.Text + " has been removed.";
                tbDeviceKey.Text = "";
            }
            catch (Exception ex)
            {
                tbStatus.Text = ex.Message;
            }
        }
    }
}
