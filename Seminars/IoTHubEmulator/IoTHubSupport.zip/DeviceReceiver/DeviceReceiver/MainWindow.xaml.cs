﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DeviceReceiver
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        string iotHubD2cEndpoint = "messages/events";
        EventHubClient eventHubClient = null;

        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        FlowDocument statusDoc = null;
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            statusDoc = new FlowDocument();
            rtbStatus.Document = statusDoc;
        }

        private void buttonReceive_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbConnectionString.Text))
            {
                MessageBox.Show("Please input Connection String!");
                return;
            }
            try
            {
                eventHubClient = EventHubClient.CreateFromConnectionString(tbConnectionString.Text, iotHubD2cEndpoint);
                statusDoc.Blocks.Add(new Paragraph(new Run("Connected to IoT Hub...")));
                var d2cPartitions = eventHubClient.GetRuntimeInformation().PartitionIds;

                foreach (string partition in d2cPartitions)
                {
                    ReceiveMessagesFromDeviceAsync(partition);
                }
            }
            catch (Exception ex)
            {
                statusDoc.Blocks.Add(new Paragraph(new Run(ex.Message)));
            }
        }

        private async Task ReceiveMessagesFromDeviceAsync(string partition)
        {
            var eventHubReceiver = eventHubClient.GetDefaultConsumerGroup().CreateReceiver(partition, DateTime.Now);
            while (true)
            {
                EventData eventData = await eventHubReceiver.ReceiveAsync();
                if (eventData == null) continue;

                string data = Encoding.UTF8.GetString(eventData.GetBytes());
                statusDoc.Blocks.Add(new Paragraph(new Run(string.Format("Message received. Partition: {0} Data: '{1}'", partition, data))));
            }
        }
    }
}
