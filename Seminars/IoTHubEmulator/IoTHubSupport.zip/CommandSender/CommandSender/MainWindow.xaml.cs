﻿using Microsoft.Azure.Devices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CommandSender
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        ServiceClient serviceClient = null;
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            statusDoc = new FlowDocument();
            rtbStatus.Document = statusDoc;
        }

        FlowDocument statusDoc;
        private async void buttonSend_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbConnectionString.Text))
            {
                MessageBox.Show("Please input Connection String.");
                return;
            }
            if (serviceClient == null)
            {
                serviceClient = ServiceClient.CreateFromConnectionString(tbConnectionString.Text);
                statusDoc.Blocks.Add(new Paragraph(new Run("Connected to IoT Hub.")));
                ReceiveFeedbackAsync();
            }
            if (string.IsNullOrEmpty(tbCommand.Text) || string.IsNullOrEmpty(tbDeviceId.Text))
            {
                MessageBox.Show("Please input Device Id and Command string.");
                return;
            }
            await SendCloudToDeviceMessageAsync(tbDeviceId.Text, tbCommand.Text);
        }

        private async Task SendCloudToDeviceMessageAsync(string deviceId, string command)
        {
            var commandMessage = new Message(Encoding.ASCII.GetBytes(command));
            commandMessage.Ack = DeliveryAcknowledgement.Full;
            await serviceClient.SendAsync(deviceId, commandMessage);
        }

        private async void ReceiveFeedbackAsync()
        {
            var feedbackReceiver = serviceClient.GetFeedbackReceiver();

            statusDoc.Blocks.Add(new Paragraph(new Run("Receiving c2d feedback from service")));
            while (true)
            {
                var feedbackBatch = await feedbackReceiver.ReceiveAsync();
                if (feedbackBatch == null) continue;

                statusDoc.Blocks.Add(new Paragraph(new Run(string.Format("Received feedback: {0}", string.Join(", ", feedbackBatch.Records.Select(f => f.StatusCode))))));

                await feedbackReceiver.CompleteAsync(feedbackBatch);
            }
        }
    }
}
