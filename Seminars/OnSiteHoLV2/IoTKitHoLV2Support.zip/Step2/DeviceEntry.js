$(function() {
    var client = new WindowsAzure.MobileServiceClient('https://[xxx].azure-mobile.net/', '[access-key]');
    var deviceEntryTable = client.getTable('deviceentry');

    // Read current data and rebuild UI.
    // If you plan to generate complex UIs like this, consider using a JavaScript templating library.
    function refreshDeviceEntries() {
        var query = deviceEntryTable.orderBy('DeviceId');

        query.read().then(function(deItems) {
            var listItems = $.map(deItems, function(item) {
                return $('<li class="device-entries">')
                    .attr('data-deitem-id', item.id).attr('data-deitem-device-id',item.deviceId)
                    .append($('<button class="item-update">Update</button>'))
                    .append($('<input type="checkbox" class="di-complete">').prop('checked', item.serviceAvailable).attr('id','item-sa-'+item.deviceId))
					.append($('<div>').append('<label class="di-text">DeviceId:'+item.deviceId+'</lablel>'))
					.append($('<div>').append('<label class="di-text">Event Hub Namespace:</lablel>')
                    .append($('<input type="text" class="di-text">').attr('id','item-ehns-'+item.deviceId).attr('value',item.eventHubNamespace)))
    				.append($('<div>').append('<label>Event Hub Name:</lablel>')
                    .append($('<input type="text" class="di-text">').attr('id','item-ehn-'+item.deviceId).attr('value',item.eventHubName)))
	   			    .append($('<div>').append('<label>Partition Name:</lablel>')
                    .append($('<input type="text" class="di-text" >').attr('id','item-ehpn-'+item.deviceId).attr('value',item.eventHubPartitionName)))
	   			    .append($('<div>').append('<label>Policy Name:</lablel>')
                    .append($('<input type="text" class="di-text" >').attr('id','item-ehpln-'+item.deviceId).attr('value', item.eventHubPolicyName)))
	    			.append($('<div>').append('<label>Access Token:</lablel>')
                    .append($('<input type="text" class="di-text" >').attr('id','item-ehat-'+item.deviceId).attr('value', item.eventHubAccessToken)));
				  
            });

            $('#device-entries').empty().append(listItems).toggle(listItems.length > 0);
            $('#summary').html('<strong>' + deItems.length + '</strong> entry(s)');
        }, handleError);
    }

    function handleError(error) {
        var text = error + (error.request ? ' - ' + error.request.status : '');
        $('#errorlog').append($('<li>').text(text));
    }

    function getDEItemId(formElement) {
        return $(formElement).closest('li').attr('data-deitem-id');
    }
	function getDEItemDevId(formElement){
		return $(formElement).closest('li').attr('data-deitem-device-id');
	}


    // Handle update
    $(document.body).on('click', '.item-update', function () {
		var itemId=getDEItemId(this);
		var itemDevId=getDEItemDevId(this);
		var elSA=document.getElementById('item-sa-'+itemDevId);
		var isServiceAvailable=true;
		if(elSA.checked!=true) {
			isServiceAvailable=false;
		}
		var elEHNS=document.getElementById('item-ehns-'+itemDevId);
		var ehns = elEHNS.value;
		var elEHN=document.getElementById('item-ehn-'+itemDevId);
		var ehn=elEHN.value;
		var elEHPN=document.getElementById('item-ehpn-'+itemDevId);
		var ehpn=elEHPN.value;
		var elEHPLN=document.getElementById('item-ehpln-'+itemDevId);
		var ehpln=elEHPLN.value;
		var elEHAT = document.getElementById('item-ehat-'+itemDevId);
		var ehat=elEHAT.value;
		deviceEntryTable.update({id: itemId, serviceAvailable: isServiceAvailable, eventHubNamespace: ehns, eventHubName: ehn, eventHubPartitionName: ehpn,eventHubPolicyName:ehpln, eventHubAccessToken: ehat }).then(refreshDeviceEntries, handleError);
 //       deviceEntryTable.del({ id: getDEItemId(this) }).then(refreshDeviceEntries, handleError);
    });

    // On initial load, start by fetching the current data
    refreshDeviceEntries();
});