﻿//#define ACCESS_MOBILE_SERVICE
//#define ACCESS_EVENT_HUB

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;

// 空白ページのアイテム テンプレートについては、http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 を参照してください

namespace IoTDevice
{
#if(ACCESS_EVENT_HUB)
    using Amqp;
    using Amqp.Framing;
#endif
#if(ACCESS_MOBILE_SERVICE)
    using Microsoft.WindowsAzure.MobileServices;
    using Newtonsoft.Json;
#endif

    /// <summary>
    /// それ自体で使用できる空白ページまたはフレーム内に移動できる空白ページ。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Device Entry Configuration
        string DeviceEntryEndPoint = "http://[mobile service name].azure-mobile.net/";
        string MobileServiceApplicationKey = "[mobile service access key]";

        // Identifier of this board. this value will be set by this app.
        Guid deviceId = new Guid(/* Your Guid */);
        
        // Event Hub Configuration
        // If you want to connect to Event Hub without Mobile Service provisioning, please set connection information by setting follows variable
        string EventHubNamespace = "";
        string EventHubName = "";
        string EventHubPatitionId = "";
        string EventHubPolicyName = "";
        string EventHubAccessToken = "";
        bool IoTServiceAvailabled = false;

        int measureIntervalMSec = 1000;
        DispatcherTimer measureTimer;
        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        IoTKitHoLSensor sensor;
        private async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            var result = await TryConnect();
            sensor = await IoTKitHoLSensor.GetCurrent(IoTKitHoLSensor.TemperatureSensor.BME280);
            measureTimer = new DispatcherTimer();
            measureTimer.Interval = TimeSpan.FromMilliseconds(measureIntervalMSec);
            measureTimer.Tick += MeasureTimer_Tick;
            measureTimer.Start();

            InitializeUpload();
        }

        //      private string DeviceId = "";
        async Task<bool> TryConnect()
        {
            bool result = false;
            var client = new Windows.Web.Http.HttpClient();
            client.DefaultRequestHeaders.Add("device-id", deviceId.ToString());
            client.DefaultRequestHeaders.Add("device-message", "Hello from RPi2");
            var response = client.GetAsync(new Uri("http://egiotkitholservice.azurewebsites.net/api/DeviceConnect"), HttpCompletionOption.ResponseContentRead);
            response.AsTask().Wait();
            var responseResult = response.GetResults();
            if (responseResult.StatusCode == Windows.Web.Http.HttpStatusCode.Ok)
            {
                result = true;
                var received = await responseResult.Content.ReadAsStringAsync();
                Debug.WriteLine("Recieved - " + received);
            }
            else
            {
                Debug.WriteLine("TryConnect Failed - " + responseResult.StatusCode);
            }
            return result;
        }
        async void InitializeUpload()
        {
            await EntryDevice();
            if (IoTServiceAvailabled)
            {
                SetupAMQP();
                uploadTimer = new DispatcherTimer();
                uploadTimer.Interval = TimeSpan.FromMilliseconds(uploadIntervalMSec);
                uploadTimer.Tick += UploadTimer_Tick;
                uploadTimer.Start();
            }
        }

        private void MeasureTimer_Tick(object sender, object e)
        {
            var sensorReading = sensor.TakeMeasurement();
            lock (this)
            {
                lastTemperature = sensorReading.Temperature;
                lastAccelX = sensorReading.AccelX;
                lastAccelY = sensorReading.AccelY;
                lastAccelZ = sensorReading.AccelZ;
            }
            Debug.WriteLine("Measured - accelx=" + sensorReading.AccelX + ",accely=" + sensorReading.AccelY + ",accelz=" + sensorReading.AccelZ + ",temperature=" + sensorReading.Temperature);
        }

        private DispatcherTimer uploadTimer;
        private long uploadIntervalMSec = 1000;

        private void UploadTimer_Tick(object sender, object e)
        {
            uploadTimer.Stop();
            Upload();
            uploadTimer.Start();
        }

        int counter = 0;
        void Upload()
        {
#if (ACCESS_EVENT_HUB)
            var now = DateTime.Now;
            var sensorReading = new Models.SensorReading()
            {
                msgId = deviceId.ToString() + now.ToString("yyyyMMddhhmmssfff")
            };
            lock (this)
            {
                sensorReading.deviceId = deviceId.ToString();
                sensorReading.temp = lastTemperature;
                sensorReading.accelx = lastAccelX;
                sensorReading.accely = lastAccelY;
                sensorReading.accelz = lastAccelZ;
                sensorReading.time = now;
            }
           var payload=  JsonConvert.SerializeObject(sensorReading);
            var message = new Message()
            {
                BodySection = new Data() { Binary = System.Text.Encoding.UTF8.GetBytes(payload) },
                Properties = new Properties() { CreationTime = now, ContentType = "text/json" }
            };
            message.ApplicationProperties = new ApplicationProperties();
            message.MessageAnnotations = new MessageAnnotations();
            try
            {
                amqpSender.Send(message, OutcomeCB, null);
                Debug.WriteLine("Send[" + counter++ + "]@" + now.Ticks);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Event Hub Send Failed:" + ex.Message);
            }
#endif
        }

#if (ACCESS_EVENT_HUB)
        private void OutcomeCB(Message message, Outcome outcome, object state)
        {
            Debug.WriteLine("Send Completed");
        }
#endif

#if (ACCESS_MOBILE_SERVICE)
        MobileServiceClient mobileService;
#endif
        private async Task EntryDevice()
        {
#if (ACCESS_MOBILE_SERVICE)
            if (mobileService == null)
            {
                mobileService = new MobileServiceClient(new Uri(DeviceEntryEndPoint), MobileServiceApplicationKey);
            }
            var table = mobileService.GetTable<Models.DeviceEntry>();
            var registered= await table.Where((de) => de.DeviceId == deviceId.ToString()).ToListAsync();
            
            bool registed = false;
            if (registered != null && registered.Count > 0)
            {
                foreach (var re in registered)
                {
                    if (re.ServiceAvailable)
                    {
                        EventHubNamespace = re.EventHubNamespace;
                        EventHubName = re.EventHubName;
                        EventHubPatitionId = re.EventHubPartitionName;
                        EventHubPolicyName = re.EventHubPolicyName;
                        EventHubAccessToken = re.EventHubAccessToken;
                        Debug.WriteLine("Event Hub Service Avaliabled");
                    }
                    registed = true;
                    break;
                }
            }
            if (!registed)
            {
                var entry = new Models.DeviceEntry()
                {
                    DeviceId = deviceId.ToString(),
                    ServiceAvailable = false,
                    EventHubNamespace = "",
                    EventHubName = "",
                    EventHubPartitionName = "",
                    EventHubPolicyName = "",
                    EventHubAccessToken = ""
                };
                await table.InsertAsync(entry);
            }
#endif
        }
        string amqpAddress = "";
#if (ACCESS_EVENT_HUB)
       Connection connection;
        Session session;
        SenderLink amqpSender;
#endif
        private void SetupAMQP()
        {
#if (ACCESS_EVENT_HUB)
            amqpAddress = "amqps://" + EventHubPolicyName + ":" + Uri.EscapeDataString(EventHubAccessToken) + "@" + EventHubNamespace + ".servicebus.windows.net";
            Address address = new Address(amqpAddress);
            lock (this)
            {
                connection = new Connection(address);
                connection.Closed = AmqpClosed;
                Debug.WriteLine("Connected to EventHub:" + EventHubName);
               session = new Session(connection);
                session.Closed = AmqpClosed;
                amqpSender = new SenderLink(session, "send-link" + EventHubName, EventHubName + "/Partitions/" + EventHubPatitionId);
                amqpSender.Closed = AmqpClosed;
            }
#endif
        }

#if (ACCESS_EVENT_HUB)
        private void AmqpClosed(AmqpObject sender, Error error)
        {
            if (sender is Connection)
            {
                Debug.WriteLine("Connection Closed");
                SetupAMQP();
            }
            else if (sender is Session)
            {
                Debug.WriteLine("Session Closed");
            }
            else if (sender is SenderLink)
            {
                Debug.WriteLine("Sender Closed");
            }
        }
#endif

        double lastTemperature;
        double lastAccelX;
        double lastAccelY;
        double lastAccelZ;
    }
}
