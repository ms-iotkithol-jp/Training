﻿using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace IoTWeb.Controllers
{
    public class SASSensorController : ApiController
    {
        public IEnumerable<Models.SASSensorTable> Get()
        {
            var storeCS = CloudConfigurationManager.GetSetting("StorageConnectionString");
            var storageAccount = CloudStorageAccount.Parse(storeCS);
            var tableClient = storageAccount.CreateCloudTableClient();
            var sensorReadingTable = tableClient.GetTableReference("SASSensor");
            var query = new TableQuery<Models.SASSensorTable>().Where(
                TableQuery.GenerateFilterConditionForDate("Timestamp",
 QueryComparisons.GreaterThanOrEqual, DateTimeOffset.Now.AddMonths(-1))
                );
            var results = sensorReadingTable.ExecuteQuery(query).
Select((ent => (Models.SASSensorTable)ent)).ToList();
            return results;

        }
    }
}
