namespace NetMFAMS42
{
    /// <summary>
    /// Interface for Mobile Services entity
    /// </summary>
    public interface IMobileServiceEntityData
    {
        /// <summary>
        /// Id
        /// </summary>
        string id { get; set; }
    }

}