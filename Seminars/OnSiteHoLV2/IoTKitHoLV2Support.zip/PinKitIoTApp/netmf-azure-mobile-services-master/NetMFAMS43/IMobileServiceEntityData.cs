namespace NetMFAMS43
{
    /// <summary>
    /// Interface for Mobile Services entity
    /// </summary>

    public interface IMobileServiceEntityData
    {
        /// <summary>
        /// id
        /// </summary>
        string id { get; set; }
    }
}
