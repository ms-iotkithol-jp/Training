//#define ACCESS_MOBILE_SERVICE
//#define ACCESS_EVENT_HUB

using System;
using Microsoft.SPOT;
using System.IO;
using System.Net;
using NetMFAMS43;
using System.Collections;
using Amqp;
using Amqp.Framing;

namespace PinKitIoTApp
{
    public partial class Program
    {
        // Device Entry Configuration
        string DeviceEntryEndPoint = "http://[mobile service name].azure-mobile.net/";
        string MobileServiceApplicationKey = "[mobile service access key]";

        // Identifier of this board. this value will be set by this app.
        String deviceId = "";

        // Event Hub Configuration
        string EventHubNamespace = "";
        string EventHubName = "";
        string EventHubPatitionId = "";
        string EventHubPolicyName = "";
        string EventHubAccessToken = "";

        bool IoTServiceAvailabled = false;

        private void TryConnect()
        {
            using (var request = HttpWebRequest.Create("http://egiotkitholservice.azurewebsites.net/api/DeviceConnect") as HttpWebRequest)
            {
                if (proxyHost != "")
                {
                    request.Proxy = new WebProxy(proxyHost, proxyPort);
                }

                if (IoTDeviceId == "" && pinkit.DeviceName != "")
                {
                    IoTDeviceId = pinkit.DeviceName;
                }
                if (IoTDeviceId != "")
                {
                    request.Headers.Add("device-id", IoTDeviceId.ToString());
                    request.Headers.Add("device-message", "hello from pinkit");
                    using (var response = request.GetResponse() as HttpWebResponse)
                    {
                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            var reader = new StreamReader(response.GetResponseStream());
                            string message = reader.ReadToEnd();
                            Debug.Print(message);
                        }
                    }
                    deviceId = IoTDeviceId;
                }
            }
        }

        void InitializeUpload()
        {
            EntryDevice();
            if (IoTServiceAvailabled)
            {
                SetupAMQP();
                uploadTimer = new DispatcherTimer();
                uploadTimer.Interval = TimeSpan.FromTicks(uploadIntervalMSec * TimeSpan.TicksPerMillisecond);
                uploadTimer.Tick += UploadTimer_Tick;
                uploadTimer.Start();
            }
        }

        int counter = 0;
        void Upload()
        {
#if (ACCESS_EVENT_HUB)
            var now = DateTime.Now;
            var sensorReading = new Models.SensorReading()
            {
                msgId = deviceId.ToString() + now.ToString("yyyyMMddhhmmssfff")
            };
            lock (this)
            {
                sensorReading.deviceId = deviceId.ToString();
                sensorReading.temp = lastTemperature;
                sensorReading.accelx = lastAccelX;
                sensorReading.accely = lastAccelY;
                sensorReading.accelz = lastAccelZ;
                sensorReading.time = now;
            }
            var serializer = new Json.NETMF.JsonSerializer(Json.NETMF.DateTimeFormat.Default);
            var payload = serializer.Serialize(sensorReading);
            var message = new Message()
            {
                BodySection = new Data() { Binary = System.Text.Encoding.UTF8.GetBytes(payload) },
                Properties = new Properties() { CreationTime = now, ContentType = "text/json" }
            };
            message.ApplicationProperties = new ApplicationProperties();
            message.MessageAnnotations = new MessageAnnotations();
            try
            {
                amqpSender.Send(message, OutcomeCB, null);
                Debug.Print("Send[" + counter++ + "]@" + now.Ticks);
            }
            catch (Exception ex)
            {
                Debug.Print("Event Hub Send Failed:" + ex.Message);
            }
#endif
        }

        private void OutcomeCB(Message message, Outcome outcome, object state)
        {
            Debug.Print("Send Completed");
        }

        DispatcherTimer measureTimer;
        DispatcherTimer uploadTimer;
        long measureIntervalMSec = 1000; // measure interval 1000 msec
        long uploadIntervalMSec = 1000;  // upload interval 1000 msec

        double lastTemperature;
        double lastAccelX;
        double lastAccelY;
        double lastAccelZ;
        private void Initialize()
        {
            InitializeUpload();

            measureTimer = new DispatcherTimer();
            measureTimer.Interval = TimeSpan.FromTicks(measureIntervalMSec * TimeSpan.TicksPerMillisecond);
            measureTimer.Tick += MeasureTimer_Tick;
            measureTimer.Start();
        }

        private void UploadTimer_Tick(object sender, EventArgs e)
        {
            uploadTimer.Stop();
            lock (this)
            {
                if (IoTServiceAvailabled)
                {
                    Upload();
                }
            }
            uploadTimer.Start();
        }

        private void MeasureTimer_Tick(object sender, EventArgs e)
        {
            measureTimer.Stop();
            lock (this)
            {
                lastTemperature = pinkit.Temperature.TakeMeasurement();
                var accel = pinkit.Accelerometer.TakeMeasurements();
                lastAccelX = accel.X;
                lastAccelY = accel.Y;
                lastAccelZ = accel.Z;
            }
            Debug.Print("Accelerometer:X=" + lastAccelX.ToString() + ",Y=" + lastAccelY.ToString() + ",Z=" + lastAccelZ.ToString());
            Debug.Print("Temperature:" + lastTemperature.ToString());
            measureTimer.Start();
        }

        MobileServiceClient mobileService;
        string DeviceEntryTableName = "DeviceEntry";
        private void EntryDevice()
        {
#if(ACCESS_MOBILE_SERVICE)
            if (mobileService == null)
            {
                mobileService = new MobileServiceClient(new Uri(DeviceEntryEndPoint), MobileServiceApplicationKey);
            }
            var queried = mobileService.Query(DeviceEntryTableName, "DeviceId%20eq%20" + deviceId);

            var registered = Json.NETMF.JsonSerializer.DeserializeString(queried) as ArrayList;
            bool registed = false;
            if (registered != null && registered.Count > 0)
            {
                foreach (var re in registered)
                {
                    var registedEntry = re as Hashtable;
                    if ((string)(registedEntry["deviceId"]) == deviceId)
                    {
                        if (registedEntry["serviceAvailable"] != null)
                        {
                            IoTServiceAvailabled = (bool)registedEntry["serviceAvailable"];
                            if (IoTServiceAvailabled)
                            {
                                EventHubNamespace = (string)registedEntry["eventHubNamespace"];
                                EventHubName = (string)registedEntry["eventHubName"];
                                EventHubPatitionId = (string)registedEntry["eventHubPartitionName"];
                                EventHubPolicyName = (string)registedEntry["eventHubPolicyName"];
                                EventHubPolicyName = (string)registedEntry["eventHubPolicyName"];
                                EventHubAccessToken = (string)registedEntry["eventHubAccessToken"];
                                Debug.Print("Event Hub Service Availabled");
                            }
                        }
                        registed = true;
                        break;
                    }
                }
            }
            if (!registed)
            {
                var entry = new Models.DeviceEntry()
                {
                    DeviceId = deviceId.ToString(),
                    ServiceAvailable = IoTServiceAvailabled,
                    EventHubNamespace = EventHubNamespace,
                    EventHubName = EventHubName,
                    EventHubPartitionName = EventHubPatitionId,
                    EventHubPolicyName = EventHubPolicyName,
                    EventHubAccessToken = EventHubAccessToken
                };
                entry.id = mobileService.Insert(DeviceEntryTableName, entry);
            }
#endif
        }
        string amqpAddress = "";
        Connection connection;
        Session session;
        SenderLink amqpSender;

        private void SetupAMQP()
        {
#if (ACCESS_EVENT_HUB)
            amqpAddress = "amqps://" + EventHubPolicyName + ":" + EGIoTKit.Utility.HttpUtility.UrlEncode(EventHubAccessToken) + "@" + EventHubNamespace + ".servicebus.windows.net";
            Address address = new Address(amqpAddress);
            lock (this)
            {
                connection = new Connection(address);
                connection.Closed = AmqpClosed;
                Debug.Print("Connected to EventHub:" + EventHubName);
                pinkit.LED.SetColor(PinKit.BoardFullColorLED.Colors.Green);
                session = new Session(connection);
                session.Closed = AmqpClosed;
                amqpSender = new SenderLink(session, "send-link" + EventHubName, EventHubName + "/Partitions/" + EventHubPatitionId);
                amqpSender.Closed = AmqpClosed;
            }
#endif
        }

        private void AmqpClosed(AmqpObject sender, Error error)
        {
            if (sender is Connection)
            {
                Debug.Print("Connection Closed");
                        SetupAMQP();
            }
            else if (sender is Session)
            {
                Debug.Print("Session Closed");
            }
            else if (sender is SenderLink)
            {
                Debug.Print("Sender Closed");
            }
        }
    }
}
