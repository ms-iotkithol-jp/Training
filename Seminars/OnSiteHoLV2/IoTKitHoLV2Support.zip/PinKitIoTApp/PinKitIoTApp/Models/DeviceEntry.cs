using System;
using Microsoft.SPOT;
using NetMFAMS43;

namespace PinKitIoTApp.Models
{
    public class DeviceEntry : IMobileServiceEntityData
    {
        public string id { get; set; }
        public string DeviceId { get; set; }
        public bool ServiceAvailable { get; set; }
        public string EventHubNamespace { get; set; }
        public string EventHubName { get; set; }
        public string EventHubPartitionName { get; set; }
        public string EventHubPolicyName { get; set; }
        public string EventHubAccessToken { get; set; }
    }
}
