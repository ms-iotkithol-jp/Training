﻿Installation Step:

PM> Install-Package WindowsAzure.MobileServices -Pre 
PM> Install-Package WindowsAzure.ServiceBus
