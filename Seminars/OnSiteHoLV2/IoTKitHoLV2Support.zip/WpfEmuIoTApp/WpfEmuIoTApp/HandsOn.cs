﻿//#define ACCESS_MOBILE_SERVICE
//#define ACCESS_EVENT_HUB
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Windows.Threading;

namespace WpfEmuIoTApp
{
#if(ACCESS_MOBILE_SERVICE)
    using Microsoft.WindowsAzure.MobileServices;
    using Newtonsoft.Json;
#endif
    public partial class MainWindow
    {
        // Device Entry Configuration
        string DeviceEntryEndPoint = "http://[mobile service name].azure-mobile.net/";
        string MobileServiceApplicationKey = "[mobile service access key]";
   
        // Identifier of this board. this value will be set by this app.
        Guid deviceId = new Guid(/* Your Guid */);

        // Event Hub Configuration
        string EventHubNamespace = "";
        string EventHubName = "";
        string EventHubPatitionId = "";
        string EventHubPolicyName = "";
        string EventHubAccessToken = "";
        bool IoTServiceAvailabled = false;

        bool TryConnect()
        {
            bool result = false;
            var request = HttpWebRequest.Create("http://egiotkitholservice.azurewebsites.net/api/DeviceConnect") as HttpWebRequest;
            request.Headers.Add("device-id", deviceId.ToString());
            request.Headers.Add("device-message", "Hello from Wpf Emulator");
            using (var response = request.GetResponse() as HttpWebResponse)
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    using (var stream = response.GetResponseStream())
                    {
                        var reader = new StreamReader(stream);
                        var content = reader.ReadToEnd();
                        Debug.WriteLine("Recieved - " + content);
                        Debug.WriteLine("TryConnect - Succeeded");
                        result = true;
                    }
                }
                else
                {
                    Debug.WriteLine("TryConnect Failed - " + response.StatusCode);
                }
            }
            return result;
        }

        async void InitializeUpload()
        {
            await EntryDevice();
            if (IoTServiceAvailabled)
            {
                SetupAMQP();
                uploadTimer = new DispatcherTimer();
                uploadTimer.Interval = TimeSpan.FromMilliseconds(uploadIntervalMSec);
                uploadTimer.Tick += UploadTimer_Tick;
                uploadTimer.Start();
            }
        }


        private DispatcherTimer uploadTimer;
        private long uploadIntervalMSec = 1000;

        private void UploadTimer_Tick(object sender, object e)
        {
            uploadTimer.Stop();
            Upload();
            uploadTimer.Start();
        }
        int sendCount = 0;
        async void Upload()
        {
#if (ACCESS_EVENT_HUB)
            if (ehSender != null)
            {
                var now = DateTime.Now;
                var sensorReading = new Models.SensorReading()
                {
                    msgId = deviceId.ToString() + now.ToString("yyyyMMddhhmmssfff")
                };
                lock (this)
                {
                    sensorReading.deviceId = deviceId.ToString();
                    sensorReading.temp = lastTemperature;
                    sensorReading.accelx = lastAccelX;
                    sensorReading.accely = lastAccelY;
                    sensorReading.accelz = lastAccelZ;
                    sensorReading.time = now;
                }
                var payload = JsonConvert.SerializeObject(sensorReading);

                var ehData = new Microsoft.ServiceBus.Messaging.EventData(Encoding.UTF8.GetBytes(payload));
                await ehSender.SendAsync(ehData);
                Debug.WriteLine("Send[" + sendCount++ + "] - Completed");
            }
#endif
        }

#if (ACCESS_EVENT_HUB)
        Microsoft.ServiceBus.Messaging.EventHubSender ehSender;
#endif
        async void SetupAMQP()
        {
#if (ACCESS_EVENT_HUB)
            string cs = "Endpoint=sb://" + EventHubNamespace +
                ".servicebus.windows.net;SharedAccessKeyName=" + EventHubPolicyName +
                ";SharedAccessKey=" + EventHubAccessToken + ";TransportType=Amqp";
            var mf = Microsoft.ServiceBus.Messaging.MessagingFactory.CreateFromConnectionString(cs);
            var eventHubClient = mf.CreateEventHubClient(EventHubName);
            ehSender = await eventHubClient.CreatePartitionedSenderAsync(EventHubPatitionId);
#endif
        }

#if (ACCESS_MOBILE_SERVICE)
        MobileServiceClient mobileService;
#endif
        private async Task EntryDevice()
        {
            try
            {
#if (ACCESS_MOBILE_SERVICE)
                if (mobileService == null)
                {
                    mobileService = new MobileServiceClient(new Uri(DeviceEntryEndPoint), MobileServiceApplicationKey);
                }
                var table = mobileService.GetTable<Models.DeviceEntry>();
                var registered = await table.Where((de) => de.DeviceId == deviceId.ToString()).ToListAsync();

                bool registed = false;
                if (registered != null && registered.Count > 0)
                {
                    foreach (var re in registered)
                    {
                        if (re.ServiceAvailable)
                        {
                            EventHubNamespace = re.EventHubNamespace;
                            EventHubName = re.EventHubName;
                            EventHubPatitionId = re.EventHubPartitionName;
                            EventHubPolicyName = re.EventHubPolicyName;
                            EventHubAccessToken = re.EventHubAccessToken;
                            IoTServiceAvailabled = re.ServiceAvailable;
                            Debug.WriteLine("Event Hub Service Avaliabled");

                            txtSBusNamesapce.Text = EventHubNamespace;
                            txtEHName.Text = EventHubName;
                            txtEHPartitionId.Text = EventHubPatitionId;
                            txtEHPolicyName.Text = EventHubPolicyName;
                            txtEHToken.Text = EventHubAccessToken;
                        }
                        registed = true;
                        break;
                    }
                }
                if (!registed)
                {
                    var entry = new Models.DeviceEntry()
                    {
                        DeviceId = deviceId.ToString(),
                        ServiceAvailable = IoTServiceAvailabled,
                        EventHubNamespace = EventHubNamespace,
                        EventHubName = EventHubName,
                        EventHubPartitionName = EventHubPatitionId,
                        EventHubPolicyName = EventHubPolicyName,
                        EventHubAccessToken = EventHubAccessToken
                    };
                    await table.InsertAsync(entry);
                }
#endif
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        double lastTemperature;
        double lastAccelX;
        double lastAccelY;
        double lastAccelZ;

    }
}
