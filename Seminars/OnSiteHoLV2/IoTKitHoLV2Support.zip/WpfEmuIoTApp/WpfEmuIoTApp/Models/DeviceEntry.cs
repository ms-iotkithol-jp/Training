﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfEmuIoTApp.Models
{
    public class DeviceEntry
    {
        public string id { get; set; }
        public string DeviceId { get; set; }
        public bool ServiceAvailable { get; set; }
        public string EventHubNamespace { get; set; }
        public string EventHubName { get; set; }
        public string EventHubPartitionName { get; set; }
        public string EventHubPolicyName { get; set; }
        public string EventHubAccessToken { get; set; }
    }
}
