﻿using Microsoft.Azure.Devices;
using Microsoft.Azure.Devices.Common.Exceptions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IoTHubDeviceMgmt
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        static RegistryManager registryManager;
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(IoTHubRFHoL.IoTHubDefinition.IoTHubOwnerConnectionString))
            {
                tbConnectionString.Text = IoTHubRFHoL.IoTHubDefinition.IoTHubOwnerConnectionString;
            }
            lvIoTHubDevices.ItemsSource = iotHubDevices;
            if (!string.IsNullOrEmpty(tbConnectionString.Text))
            {
                await UpdateIoTHubDeviceEntries();
                UpdateButtonConnectedState();
            }
        }

        private async void buttonUpdate_Click(object sender, RoutedEventArgs e)
        {
            await UpdateIoTHubDeviceEntries();
        }

        private async void buttonRegistDevice_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbDeviceId.Text))
            {
                return;
            }
            if (registryManager == null)
            {
                registryManager = RegistryManager.CreateFromConnectionString(tbConnectionString.Text);
            }
            try
            {
                var device = await registryManager.AddDeviceAsync(new Device(tbDeviceId.Text));
                await UpdateIoTHubDeviceEntries();
                tbDeviceKey.Text = device.Authentication.SymmetricKey.PrimaryKey;
            }
            catch (DeviceAlreadyExistsException ex)
            {
                var device = await registryManager.GetDeviceAsync(tbDeviceId.Text);
                MessageBox.Show("Device has been registed!");
                tbDeviceKey.Text = device.Authentication.SymmetricKey.PrimaryKey;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        ObservableCollection<IoTHubDeviceEntryItem> iotHubDevices = new ObservableCollection<IoTHubDeviceEntryItem>();
        private async Task UpdateIoTHubDeviceEntries()
        {
            if (registryManager == null)
            {
                registryManager = RegistryManager.CreateFromConnectionString(tbConnectionString.Text);
            }
            iotHubDevices.Clear();
            int maxCount = 100;
            for (;;)
            {
                var devices = await registryManager.GetDevicesAsync(maxCount);
                foreach (var d in devices)
                {
                    iotHubDevices.Add(new IoTHubDeviceEntryItem()
                    {
                        DeviceId = d.Id,
                        DeviceKey = d.Authentication.SymmetricKey.PrimaryKey
                    });
                }
                if (devices.Count() < maxCount)
                    break;
            }
        }

        IoTHubDeviceEntryItem currentSelectedItem = null;
        private void lvIoTHubDevices_Selected(object sender, RoutedEventArgs e)
        {
            var selected = (IoTHubDeviceEntryItem)(((ListView)sender).SelectedItem);
            if (selected != null)
            {
                tbDeviceId.Text = selected.DeviceId;
                tbDeviceKey.Text = selected.DeviceKey;
                currentSelectedItem = selected;
            }
        }

        private void buttonCopyDeviceKey_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetData(DataFormats.Text, tbDeviceKey.Text);
        }

        private async void buttonRemove_Click(object sender, RoutedEventArgs e)
        {
            if (currentSelectedItem != null)
            {
                lvIoTHubDevices.SelectedItem = null;
                await registryManager.RemoveDeviceAsync(currentSelectedItem.DeviceId);
                currentSelectedItem = null;
                await UpdateIoTHubDeviceEntries();
            }
        }

        private async void buttonConnect_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbConnectionString.Text))
            {
                MessageBox.Show("Please input 'Connection String'");
                return;
            }
            await UpdateIoTHubDeviceEntries();
            UpdateButtonConnectedState();
        }

        private void UpdateButtonConnectedState()
        {
            buttonRegistDevice.IsEnabled = true;
      //      buttonRemove.IsEnabled = true;
            buttonUpdate.IsEnabled = true;
        }
    }

    class IoTHubDeviceEntry
    {
        public string DeviceId { get; set; }
        public string DeviceKey { get; set; }
    }

    class IoTHubDeviceEntryItem : IoTHubDeviceEntry, INotifyPropertyChanged
    {
        public new string DeviceId
        {
            get { return base.DeviceId; }
            set
            {
                base.DeviceId = value;
                OnPropertyChanged("DeviceId");
            }
        }
        public new string DeviceKey
        {
            get { return base.DeviceKey; }
            set
            {
                base.DeviceKey = value;
                OnPropertyChanged("DeviceKey");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
    }
}
