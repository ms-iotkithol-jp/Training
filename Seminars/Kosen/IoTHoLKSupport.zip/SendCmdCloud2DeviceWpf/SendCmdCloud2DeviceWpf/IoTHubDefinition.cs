﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IoTHubRFHoL
{
    class IoTHubDefinition
    {
        public const string IoTHubEndPoint = "";
        public const string IoTHubOwnerConnectionString = "";
        public const string IoTHubServiceConnectionString = "";
        public static readonly double? Latitude = null;
        public static readonly double? Longitude = null;
    }
}
