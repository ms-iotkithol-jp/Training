// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef SAL_H
#define SAL_H

#include "no_sal2.h"

#endif
