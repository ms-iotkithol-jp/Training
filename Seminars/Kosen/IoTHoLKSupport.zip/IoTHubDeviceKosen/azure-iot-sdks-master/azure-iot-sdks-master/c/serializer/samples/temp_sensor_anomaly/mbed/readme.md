# To build the sample

Follow the instructions [here](https://github.com/Azure/azure-iot-sdks/blob/master/c/doc/run_sample_on_freescale_k64f_mbed.md).

In addition to the libraries to be imported from the link above, the following libraries need to be imported:

https://developer.mbed.org/users/chris/code/C12832/ 
https://developer.mbed.org/users/neilt6/code/LM75B/
