// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "remote_monitoring.h"

int main(void)
{
    remote_monitoring_run();

    return 0;
}
