// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "../codefirst_withstructs_unittests/codefirst_withstructs_unittests.cpp"
