﻿using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using GIS = GHIElectronics.UWP.Shields;

// 空白ページのアイテム テンプレートについては、http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 を参照してください

namespace IoTHubDeviceKosen
{

    /// <summary>
    /// それ自体で使用できる空白ページまたはフレーム内に移動できる空白ページ。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Device Id
        string deviceId = "RFK_[Your Device Id]";

        double longitude = 139.740987;
        double latitude = 35.62661;

        // IoT Hub Configuration
        string IoTHubEndpoint = "[IoT Hub Name].azure-devices.net";
        string DeviceKey = "[Device Key]";
        bool IoTServiceAvailabled = true;

        int measureIntervalMSec = 1000;
        DispatcherTimer measureTimer;

        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        private async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            FixDeviceId();
            if (!string.IsNullOrEmpty(IoTHubRFHoL.IoTHubDefinition.IoTHubEndPoint))
            {
                IoTHubEndpoint = IoTHubRFHoL.IoTHubDefinition.IoTHubEndPoint;
                if (IoTHubRFHoL.IoTHubDefinition.Latitude != null && IoTHubRFHoL.IoTHubDefinition.Longitude != null)
                {
                    latitude = IoTHubRFHoL.IoTHubDefinition.Latitude.Value;
                    longitude = IoTHubRFHoL.IoTHubDefinition.Longitude.Value;
                }
            }
            tbDeviceId.Text = deviceId;
            fezHat = await GIS.FEZHAT.CreateAsync();
            fezHat.D2.TurnOff();
            fezHat.D3.TurnOff();
            lastSensorReading = new List<SensorReadingBuffer>();

            measureTimer = new DispatcherTimer();
            measureTimer.Interval = TimeSpan.FromMilliseconds(measureIntervalMSec);
            measureTimer.Tick += MeasureTimer_Tick;
            measureTimer.Start();

            InitializeUpload();
        }

#pragma warning restore 4014

        private void MeasureTimer_Tick(object sender, object e)
        {
            double x, y, z;
            fezHat.GetAcceleration(out x, out y, out z);
            double temp = fezHat.GetTemperature();
            double brightness = fezHat.GetLightLevel();
            var timestamp = DateTime.Now;
            lock (this)
            {
                lastSensorReading.Add(new SensorReadingBuffer()
                {
                    AccelX = x,
                    AccelY = y,
                    AccelZ = z,
                    Temperature = temp,
                    Brightness = brightness,
                    Timestamp = timestamp
                });
            }
            Debug.WriteLine("[" + timestamp.ToString("yyyyMMdd-hhmmss.fff") + "]T=" + temp + ",B=" + brightness + ",AccelX=" + x + ",AccelY=" + y + ",AccelZ=" + z);
        }

        DispatcherTimer uploadTimer;
        long uploadIntervalMSec = 120000;
        async void InitializeUpload()
        {
            if (IoTServiceAvailabled)
            {
                SetupIoTHub();
                uploadTimer = new DispatcherTimer();
                uploadTimer.Interval = TimeSpan.FromMilliseconds(uploadIntervalMSec);
                uploadTimer.Tick += UploadTimer_Tick; ;
                uploadTimer.Start();
            }
        }
        DeviceClient deviceClient;

        private void SetupIoTHub()
        {
            try
            {
                tbConnStatus.Text = "Connecting...";
                deviceClient = DeviceClient.Create(IoTHubEndpoint, AuthenticationMethodFactory.CreateAuthenticationWithRegistrySymmetricKey(deviceId.ToString(), DeviceKey), TransportType.Http1);
                tbConnStatus.Text = "Connected - " + IoTHubEndpoint;
                IndicateDebug(GIS.FEZHAT.Color.Green, 10);

                ReceiveCommands();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        private async void UploadTimer_Tick(object sender, object e)
        {
            uploadTimer.Stop();
            await SendEvent();
            uploadTimer.Start();
        }

        List<SensorReadingBuffer> lastSensorReading;
        int sendCount = 0;

        async Task SendEvent()
        {
            List<SensorReadingBuffer> currentReadings = new List<SensorReadingBuffer>();
            lock (this)
            {
                foreach (var r in lastSensorReading)
                {
                    currentReadings.Add(new SensorReadingBuffer()
                    {
                        AccelX = r.AccelX,
                        AccelY = r.AccelY,
                        AccelZ = r.AccelZ,
                        Temperature = r.Temperature,
                        Brightness = r.Brightness,
                        Timestamp = r.Timestamp
                    });
                }
                lastSensorReading.Clear();
            }
            Debug.WriteLine("Device sending {0} messages to IoTHub...\n", currentReadings.Count);

            try
            {
                List<Models.SensorReading> sendingBuffers = new List<Models.SensorReading>();
                for (int count = 0; count < currentReadings.Count; count++)
                {
                    var sensorReading = new Models.SensorReading()
                    {
                        msgId = deviceId.ToString() + currentReadings[count].Timestamp.ToString("yyyyMMddhhmmssfff"),
                        accelx = currentReadings[count].AccelX,
                        accely = currentReadings[count].AccelY,
                        accelz = currentReadings[count].AccelZ,
                        deviceId = deviceId.ToString(),
                        temp = currentReadings[count].Temperature,
                        brightness = currentReadings[count].Brightness,
                        time = currentReadings[count].Timestamp,
                        Longitude = longitude,
                        Latitude = latitude
                    };
                    sendingBuffers.Add(sensorReading);
                }
                var payload = JsonConvert.SerializeObject(sendingBuffers);
                Message eventMessage = new Message(Encoding.UTF8.GetBytes(payload));
                Debug.WriteLine("\t{0}> Sending message: {1}, Data: [{2}]", DateTime.Now.ToLocalTime(), currentReadings.Count, payload);

                await deviceClient.SendEventAsync(eventMessage);
                tbSendStatus.Text = "Send[" + sendCount++ + "]@" + DateTime.Now.ToString();
                IndicateDebug(GIS.FEZHAT.Color.Blue, 10);
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                IndicateDebug(GIS.FEZHAT.Color.Yellow, 3600);
            }
        }


        async Task ReceiveCommands()
        {
            Debug.WriteLine("\nDevice waiting for commands from IoTHub...\n");
            Message receivedMessage;
            string messageData;

            while (true)
            {
                try
                {
                    receivedMessage = await deviceClient.ReceiveAsync();

                    if (receivedMessage != null)
                    {
                        messageData = Encoding.ASCII.GetString(receivedMessage.GetBytes());
                        Debug.WriteLine("\t{0}> Received message: {1}", DateTime.Now.ToLocalTime(), messageData);
                        tbReceiveStats.Text = "Received - " + messageData + " - @" + DateTime.Now.ToString();
                        var command = messageData.ToLower();
                        if (command.StartsWith("fezhat:"))
                        {
                            var units = command.Split(new char[] { ':' });
                            var unit = units[1].Split(new char[] { ',' });
                            foreach (var order in unit)
                            {
                                GIS.FEZHAT.RgbLed targetLed = null;
                                var frags = order.Split(new char[] { '=' });
                                switch (frags[0].ToUpper())
                                {
                                    case "D2":
                                        targetLed = fezHat.D2;
                                        break;
                                    case "D3":
                                        targetLed = fezHat.D3;
                                        break;
                                }
                                var orderedColor = GIS.FEZHAT.Color.Black;
                                switch (frags[1].ToLower())
                                {
                                    case "black":
                                        orderedColor = GIS.FEZHAT.Color.Black;
                                        break;
                                    case "red":
                                        orderedColor = GIS.FEZHAT.Color.Red;
                                        break;
                                    case "green":
                                        orderedColor = GIS.FEZHAT.Color.Green;
                                        break;
                                    case "yellow":
                                        orderedColor = GIS.FEZHAT.Color.Yellow;
                                        break;
                                    case "blue":
                                        orderedColor = GIS.FEZHAT.Color.Blue;
                                        break;
                                    case "magenta":
                                        orderedColor = GIS.FEZHAT.Color.Magneta;
                                        break;
                                    case "cyan":
                                        orderedColor = GIS.FEZHAT.Color.Cyan;
                                        break;
                                    case "white":
                                        orderedColor = GIS.FEZHAT.Color.White;
                                        break;
                                }
                                targetLed.Color = orderedColor;
                            }
                        }
                        await deviceClient.CompleteAsync(receivedMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    IndicateDebug(GIS.FEZHAT.Color.Red, 3600);
                }
                await Task.Delay(TimeSpan.FromSeconds(10));
            }

        }

        private void FixDeviceId()
        {
            foreach (var hn in Windows.Networking.Connectivity.NetworkInformation.GetHostNames())
            {
                IPAddress ipAddr;
                if (!hn.DisplayName.EndsWith(".local") && !IPAddress.TryParse(hn.DisplayName, out ipAddr))
                {
                    deviceId = hn.DisplayName;
                    break;
                }
            }
        }

        private GIS.FEZHAT fezHat;

        DispatcherTimer debugTimer;
        int debugCount = 0;
        int debugRound = 0;
        GIS.FEZHAT.Color debugColor;
        void IndicateDebug(GIS.FEZHAT.Color color, int round)
        {
            if (debugTimer == null)
            {
                debugTimer = new DispatcherTimer();
                debugTimer.Interval = TimeSpan.FromMilliseconds(500);
                debugTimer.Tick += DebugTimer_Tick;
            }
            debugCount = 0;
            debugRound = round;
            debugColor = color;
            debugTimer.Start();
        }

        private void DebugTimer_Tick(object sender, object e)
        {
            if ((debugCount % 2) == 0)
            {
                fezHat.D3.Color = debugColor;
            }
            else
            {
                fezHat.D3.TurnOff();
            }
            debugCount++;
            if (debugCount > debugRound)
            {
                fezHat.D3.TurnOff();
                debugTimer.Stop();
            }
        }
    }

    class SensorReadingBuffer
    {
        public double Temperature { get; set; }
        public double Brightness { get; set; }
        public double AccelX { get; set; }
        public double AccelY { get; set; }
        public double AccelZ { get; set; }
        public DateTime Timestamp { get; set; }
    }

}
